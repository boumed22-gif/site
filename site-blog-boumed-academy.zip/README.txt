INSTALLATION SUR GITHUB PAGES

1. Ouvrez le dépôt boumed22-gif/site.
2. Supprimez ou remplacez l'ancien index.html.
3. Téléversez tous les éléments contenus dans ce dossier :
   - index.html
   - assets/
   - blog/
4. Validez avec « Commit changes ».
5. Attendez environ 1 à 3 minutes.

Adresses obtenues :
Accueil : https://boumed22-gif.github.io/site/
Articles : https://boumed22-gif.github.io/site/blog/
Article RC : https://boumed22-gif.github.io/site/blog/dipole-rc/
